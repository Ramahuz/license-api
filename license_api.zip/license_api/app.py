from flask import Flask, request, jsonify
import json

app = Flask(__name__)

def load_licenses():
    with open("licenses.json", "r") as f:
        return json.load(f)

@app.route("/")
def home():
    return "License API aktif."

@app.route("/verify", methods=["POST"])
def verify():
    data = request.get_json()
    username = data.get("username")
    license_key = data.get("license")
    version = data.get("version")

    licenses = load_licenses()

    for entry in licenses:
        if (entry["username"] == username and
            entry["license"] == license_key and
            entry["version"] == version):
            return jsonify({"valid": True})

    return jsonify({"valid": False})

if __name__ == "__main__":
    app.run()
